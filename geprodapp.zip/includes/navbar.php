<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Gluttire</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item"><a class="nav-link" href="index.php">Inicio</a></li>
            <li class="nav-item"><a class="nav-link" href="alta_receta.php">Alta Receta</a></li>
            <li class="nav-item"><a class="nav-link" href="entradas.php">Entradas</a></li>
            <li class="nav-item"><a class="nav-link" href="produccion.php">Producción</a></li>
            <li class="nav-item"><a class="nav-link" href="usuarios.php">Usuarios</a></li>
            <li class="nav-item"><a class="nav-link" href="listproduccion.php">Informes</a></li>
            <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
        </ul>
    </div>
</nav>